
class Usuario{
  bool online;
  String email;
  String nombre;
  String uid;

  Usuario({
    required this.online,
    required this.email,
    required this.nombre,
    required this.uid,
  });
  
}
package com.example.pruebas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
